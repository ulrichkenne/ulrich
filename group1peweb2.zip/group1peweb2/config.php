<?php

$conn = mysqli_connect('localhost','root','','kamel') or die('connection failed');
?>