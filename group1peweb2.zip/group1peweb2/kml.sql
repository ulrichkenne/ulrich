-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : lun. 11 mars 2024 à 12:08
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `shop_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `quantity` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

CREATE TABLE `message` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

CREATE TABLE `orders` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `number` varchar(12) NOT NULL,
  `email` varchar(100) NOT NULL,
  `method` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `total_products` varchar(1000) NOT NULL,
  `total_price` int(100) NOT NULL,
  `placed_on` varchar(50) NOT NULL,
  `payment_status` varchar(20) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `parrain`
--

CREATE TABLE `parrain` (
  `id_p` int(11) NOT NULL,
  `nom_p` varchar(50) NOT NULL,
  `prenom_p` varchar(50) NOT NULL,
  `classe` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `parrain`
--

INSERT INTO `parrain` (`id_p`, `nom_p`, `prenom_p`, `classe`) VALUES
(4, 'kadji', 'yan', 'sr2'),
(6, 'kamel', 'poumie', 'sr2'),
(17, 'nn', 'bb', 'sr2');

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

CREATE TABLE `products` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `price` int(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL DEFAULT 'user',
  `class` varchar(10) NOT NULL,
  `uniqid` varchar(13) NOT NULL,
  `id_p` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `user_type`, `class`, `uniqid`, `id_p`) VALUES
(2, 'nuit', 'yaziddoun@gmail.com', '68ec81ba3ed4f7d61931d86bfd0e6006', 'user', '', '', 0),
(4, 'kml', 'kamelpoumie613@gmail.com', '68ec81ba3ed4f7d61931d86bfd0e6006', 'admin', '', '', 0),
(6, 'ziyad', 'ziyad1@gmail.com', '68ec81ba3ed4f7d61931d86bfd0e6006', 'admin', '', '', 0),
(10, 'mounchlili', 'yaziddounya83@gmail.com', '864a9912efeba8e9dd080cac32200d20', 'admin', '', '', 0),
(11, 'kamel_b', 'kamelpoumie@gmail.com', '68ec81ba3ed4f7d61931d86bfd0e6006', 'user', '', '', 0),
(12, 'kamel', 'kamelpoumie3@gmail.com', '68ec81ba3ed4f7d61931d86bfd0e6006', 'user', '', '', 0),
(13, 'issah mounchili', 'yaziddounya@gmail.com', 'd9308f32f8c6cf370ca5aaaeafc0d49b', '', '', '', 0),
(14, 'kalil', 'yaziddouny@gmail.com', '68ec81ba3ed4f7d61931d86bfd0e6006', 'user', '', '', 0),
(15, 'kalil1', 'yaziddoun@gmail.com', '68ec81ba3ed4f7d61931d86bfd0e6006', 'user', '', '', 0),
(16, 'bonsoir', 'yazidi@gmail.com', '864a9912efeba8e9dd080cac32200d20', 'user', 'SR', '', 0),
(17, 'ajebe', 'emmanueladrien16@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b', 'user', 'GL', '', 0),
(18, 'maradia', 'maradia@gmail.com', '1c49c0a4aadbe4d4d449ce7a10f8b72a', 'user', 'SR', '', 0),
(19, 'pp', 'kamelghost10@gmail.com', 'f7c0e071db137f5ae65382041c7cef4b', 'user', 'GL', '', 0),
(20, 'boo', 'boo@gmail.com', '38f629170ac3ab74b9d6d2cc411c2f3c', 'user', 'SR', '', 0),
(21, 'kml', 'kamelghost10@gmail.com', 'd9308f32f8c6cf370ca5aaaeafc0d49b', 'user', 'SR', '', 0),
(22, 'ikashi', 'ikashi123@gmail.com', '670da91be64127c92faac35c8300e814', 'user', 'GL', '', 0);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `parrain`
--
ALTER TABLE `parrain`
  ADD PRIMARY KEY (`id_p`);

--
-- Index pour la table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT pour la table `message`
--
ALTER TABLE `message`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `parrain`
--
ALTER TABLE `parrain`
  MODIFY `id_p` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT pour la table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
